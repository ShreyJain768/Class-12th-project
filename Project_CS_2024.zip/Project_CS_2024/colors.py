
def BLACK():
    print("\033[0;30m")

def RED():
    print("\033[0;31m")

def GREEN():  
    print("\033[0;32m")

def BROWN():  
    print("\033[0;33m")

def ORANGE():
    print("\033[33m")

def BLUE():  
    print("\033[0;34m")

def PURPLE():  
    print("\033[0;35m")

def CYAN():  
    print("\033[0;36m")

def LIGHT_GRAY():  
    print("\033[0;37m")

def DARK_GRAY():  
    print("\033[1;30m")

def LIGHT_RED():  
    print("\033[1;31m")

def LIGHT_GREEN():  
    print("\033[1;32m")

def YELLOW():  
    print("\033[1;33m")

def LIGHT_BLUE():  
    print("\033[1;34m")

def LIGHT_PURPLE():  
    print("\033[1;35m")

def LIGHT_CYAN():  
    print("\033[1;36m")

def LIGHT_WHITE():  
    print("\033[1;37m")

def BOLD():  
    print("\033[1m")

def FAINT():  
    print("\033[2m")

def ITALIC():  
    print("\033[3m")

def UNDERLINE():  
    print("\033[4m")

def BLINK():  
    print("\033[5m")

def NEGATIVE():  
    print("\033[7m")

def CROSSED():  
    print("\033[9m")
    
def stop():
    print("\033[0m")