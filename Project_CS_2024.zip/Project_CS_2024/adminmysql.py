import mysql.connector, con_login, st_info, tabulate


con = mysql.connector.connect(
  host="localhost",
  user="root",
  password="rj1212007"
)
mycursor = con.cursor()

mycursor.execute("create database if not exists names;")

con.commit()


def uact():
    username = input("Enter Your Name = ")
    userpass = input("Enter Password = ")
    mycursor.execute("use names")
    mycursor.execute("create table if not exists unames(Id int auto_increment ,Names varchar(50),Passwords varchar(50) ,primary key(Id));")
    mycursor.execute(f"insert into unames(Names,Passwords) values('{username}','{userpass}');")
    inserted_id = mycursor.lastrowid
    print(f"Your User Id is = {inserted_id}")
    con.commit()
    input("Press Enter to Continue.")

def fetching_data(x):
    try:
        mycursor.execute("use names")
        mycursor.execute("create table if not exists unames(Id int auto_increment ,Names varchar(50),Passwords varchar(50) ,primary key(Id));")
        mycursor.execute(f"select Passwords from unames where Id={x};")
        stored = mycursor.fetchall()
        return x,stored[0][0]
    except Exception as e:
        print("Given Id or password is wrong.")
        con_login.voice("Given Id or password is wrong.")
        con_login.login_back(1)
def ad_acc_det():
    mycursor.execute("use names;")
    mycursor.execute("select * from unames;")
    a = mycursor.fetchall()
    return a
        
def buying(p):
    try:
        st_info.all_stocks()
        table = con_login.ft()
        print(tabulate.tabulate(table, headers=["Stocks", "Price", "", "Stocks", "Price"], tablefmt="grid"))
        con_login.voice("Please enter the data carefully")
        while True:
            mycursor.execute("SELECT Names FROM unames WHERE Id = %s;", (p,))
            u = str(mycursor.fetchall()[0][0])
            while True:
                names_of_st = input("Enter stock name as it is you want to buy = ")
                chose = stk_names(names_of_st)
                if chose != None:
                    break 
            price_of_st = int(input("Enter stock current price = "))
            qty = int(input("Provide the quantity of the interested stock = "))
            
            mycursor.execute("USE names;")
            mycursor.execute(
                f"CREATE TABLE IF NOT EXISTS `{p}` ("
                "`Id` INT AUTO_INCREMENT,"
                "`Name` VARCHAR(50), "
                "`Stock Name` VARCHAR(50), "
                "`Stock Price` INT, "
                "`Stock Quantity` INT,"
                "`Total Cost` INT, PRIMARY KEY(`Id`))"
            )
            
            mycursor.execute(
                f"INSERT INTO `{p}` (`Id`, `Name`, `Stock Name`, `Stock Price`, `Stock Quantity`, `Total Cost`) "
                "VALUES (1000, 'yooo', 'gooo', 94759, 100, 123)"
            )
            mycursor.execute(
                f"INSERT INTO `{p}` (`Name`, `Stock Name`, `Stock Price`, `Stock Quantity`, `Total Cost`) "
                "VALUES (%s, %s, %s, %s, %s)",
                ('user', chose, price_of_st, qty, price_of_st * qty)
            )
            mycursor.execute(
                f"DELETE FROM `{p}` WHERE `Id` = 1000"
            )
            g = input("Do you Want to buy more stocks (y/n) ==> ")
            if g.lower() == "n":
                break
        input("Press Enter to continue.")
            

    except Exception as e:
        print("Someting is going wrong, Please try again later.")
        input("Press Enter to continue.")
        
    
    con.commit()



def holdings(p):
    mycursor.execute("use names;")
    mycursor.execute(f"select Names from unames where Id={p};")
    u = str(mycursor.fetchall()[0][0])
    mycursor.execute(f"select * from `{p}`;")
    n = mycursor.fetchall()
    print(tabulate.tabulate(n,headers = ["Id","Name","Stock Name","Stock Price","Stock Quantity","Total Cost"], tablefmt = "grid"))


def selling(p):
    while True:
        mycursor.execute("USE names;")
        mycursor.execute(f"SELECT Names FROM unames WHERE Id = {p}")
        u = mycursor.fetchone()[0]
        k = int(input("Input Id of the share which you want to sale = "))
        delete_query = f"SELECT `Stock Quantity` FROM `{p}` WHERE `Id` = %s"
        mycursor.execute(delete_query, (k,))
        no_st = int(mycursor.fetchone()[0])
        sel_no_stock = int(input("Input the number of share do you want to sale = "))
        try:
            if no_st == sel_no_stock:
                mycursor.execute(F"DELETE FROM `{p}` WHERE `Id`={k}")
                print("Stock sold successfully.")
            elif no_st > sel_no_stock:
                mycursor.execute(f"UPDATE `{p}` SET `Stock Quantity`={no_st-sel_no_stock} WHERE `Id`={k}")
                mycursor.execute(f"select `Stock Price` from `{p}` where `Id`={k}")
                a = int(mycursor.fetchone()[0])
                mycursor.execute(f"UPDATE `{p}` SET `Total Cost`={(no_st-sel_no_stock)*a} WHERE `Id`={k}")
                print("Stock sold successfully.")
            else:
                print("Input correct Data.")
        except Exception as e:
            print("Input correct Data.")
        g = input("Do you Want to sell more stocks (y/n) ==> ")
        if g.lower() == "n":
            break
        input("Press Enter to continue.")
    con.commit()
    
def stk_names(q):
    if q.lower() == 'HDFC Bank'.lower():
        return 'HDFC Bank'

    elif q.lower() == 'Reliance'.lower():
        return 'Reliance'

    elif q.lower() == 'Infosys'.lower():
        return 'Infosys'

    elif q.lower() == 'Tata Motors'.lower():
        return 'Tata Motors'

    elif q.lower() == 'ONGC'.lower():
        return 'ONGC'

    elif q.lower() == 'ICICI Bank'.lower():
        return 'ICICI Bank'

    elif q.lower() == 'Wipro'.lower():
        return 'Wipro'

    elif q.lower() == 'Bajal Finance'.lower():
        return 'Bajal Finance'

    elif q.lower() == 'Nestle'.lower():
        return 'Nestle'

    elif q.lower() == 'BPCL'.lower():
        return 'BPCL'

    elif q.lower() == 'Gold MCX'.lower():
        return 'Gold MCX'

    elif q.lower() == 'Silver MCX'.lower():
        return 'Silver MCX'

    elif q.lower() == 'IGL'.lower():
        return 'IGL'

    elif q.lower() == 'SBI'.lower():
        return 'SBI'

    elif q.lower() == 'TCS'.lower():
        return 'TCS'

    elif q.lower() == 'HCL Tech'.lower():
        return 'HCL Tech'

    elif q.lower() == 'Tata Steel'.lower():
        return 'Tata Steel'

    elif q.lower() == 'ITC'.lower():
        return 'ITC'

    elif q.lower() == 'HUL'.lower():
        return 'HUL'

    elif q.lower() == 'Cipla'.lower():    
        return 'Cipla'

    else:
        return None                     