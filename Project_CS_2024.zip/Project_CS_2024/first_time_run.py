import mysql.connector


con = mysql.connector.connect(
  host="localhost",
  user="root",
  password="rj1212007"
)
mycursor = con.cursor()
try:
  mycursor.execute("drop database names;")
  mycursor.execute("use names;")
  mycursor.execute("create table if not exists unames(Id int auto_increment ,Names varchar(50),Passwords varchar(50) ,primary key(Id));")
  mycursor.execute("insert into unames(Id,Names,Passwords) values(101,'Shrey Jain','us123');")
  mycursor.execute("insert into unames(Names,Passwords) values('Sarthak Singh','helloworld');")
  mycursor.execute("insert into unames(Names,Passwords) values('Gaurav Mittal','thinking');")
except Exception as e:
  mycursor.execute("create database if not exists names;")
  mycursor.execute("use names;")
  mycursor.execute("create table if not exists unames(Id int auto_increment ,Names varchar(50),Passwords varchar(50) ,primary key(Id));")
  mycursor.execute("insert into unames(Id,Names,Passwords) values(101,'Shrey Jain','us123');")
  mycursor.execute("insert into unames(Names,Passwords) values('Sarthak Singh','helloworld');")
  mycursor.execute("insert into unames(Names,Passwords) values('Gaurav Mittal','thinking');")

con.commit()