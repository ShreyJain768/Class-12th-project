import con_login, colors

def front_lo():
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    print("\033[5m\033[1;33m\033[1m" + "\t\t\t\t\t|     Stock Exchange Pvt. Ltd     |" + '\033[0m')
    print("\t\t\t\t\t\t\t\t\t\t\t\t\t Login(1)" , end="\n\n")
    print("\t\tStock Price (2)")
    print("\t\tStock Fortune (3)",end = "\n\n")
    print("\t\t\t\t\t\t\t\t\t\t\t\t   Contact Us (4)", end = "\n\n\n\n")
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    bata = int(input("\033[A\033[A\033[A\033[A\033[A==>")) 
    print("\n")
    return bata
    
    

def front_user():
    print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
    print("\033[5m\033[1;33m\033[1m" + "\t\t\t\t\t\tStock Exchange Pvt. Ltd.\n" + '\033[0m')
    print("\033[5m\033[1;33m\033[1m" + "\t\t\t\t\t\t      Hello User" + '\033[0m')
    print("\t\t\t\t\t\t\t\t\t\t\t\t\t Logout(2)" , end="\n\n")
    print("\t\tStock Price (3)")
    print("\t\tStock Fortune (4)")
    print("\t\tShare Holdings and Sell (5)")
    print("\t\tBuy (8)")
    print("\t\tAccount Details (6)",end="\n\n\n")
    print("\t\t\t\t\t\t\t\t\t\t\t\t      Contact Us (7)" , end="\n\n")
    print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
    con_login.voice("Welcome User")
    



def front_admin():
    print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
    print("\033[5m\033[1;33m\033[1m" +"\t\t\t\t\t\tStock Exchange Pvt. Ltd.\n"+ '\033[0m')
    print("\033[5m\033[1;33m\033[1m" +"\t\t\t\t\t\t      Hello Admin" + '\033[0m')
    print("\t\t\t\t\t\t\t\t\t\t\t\t\t Logout (2)" , end="\n\n")
    print("\t\tStock Price (3)")
    print("\t\tStock Fortune (4)")
    print("\t\tAccount Details (6)",end="\n\n\n")
    print("",end="\n")
    print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
    con_login.voice("Logged into Admin domain")

