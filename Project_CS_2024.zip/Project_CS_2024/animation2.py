import tabulate, random, time, mysql.connector, con_login , st_info





def new(a):
    if a%34 == 0 :
        print("\033[1m\033[1;33m" + "|   Stock Exchange Pvt. Ltd       |" + '\033[0m', end = "")
    elif a%33 == 0 :
        print("\033[1m\033[1;33m" + "|tock Exchange Pvt. Ltd          S|" + '\033[0m', end = "")
    elif a%32 == 0 :
        print("\033[1m\033[1;33m" + "|ock Exchange Pvt. Ltd          St|" + '\033[0m', end = "")
    elif a%31 == 0 :
        print("\033[1m\033[1;33m" + "|ck Exchange Pvt. Ltd          Sto|" + '\033[0m', end = "")
    elif a%30 == 0 :
        print("\033[1m\033[1;33m" + "|K Exchange Pvt. Ltd          Stoc|" + '\033[0m', end = "")
    elif a%29 == 0 :
        print("\033[1m\033[1;33m" + "| Exchange Pvt. Ltd          Stock|" + '\033[0m', end = "")
    elif a%28 == 0 :
        print("\033[1m\033[1;33m" + "|Exchange Pvt. Ltd          Stock |" + '\033[0m', end = "")
    elif a%27 == 0 :
        print("\033[1m\033[1;33m" + "|xchange Pvt. Ltd          Stock E|" + '\033[0m', end = "")
    elif a%26 == 0 :
        print("\033[1m\033[1;33m" + "|change Pvt. Ltd          Stock Ex|" + '\033[0m', end = "")
    elif a%25 == 0 :
        print("\033[1m\033[1;33m" + "|hange Pvt. Ltd          Stock Exc|" + '\033[0m', end = "")
    elif a%24 == 0 :
        print("\033[1m\033[1;33m" + "|ange Pvt. Ltd          Stock Exch|" + '\033[0m', end = "")
    elif (a%23) == 0 :
        print("\033[1m\033[1;33m" + "|nge Pvt. Ltd          Stock Excha|" + '\033[0m', end = "")
    elif (a%22) == 0 :
        print("\033[1m\033[1;33m" + "|ge Pvt. Ltd          Stock Exchan|" + '\033[0m', end = "")
    elif a%21 == 0 :
        print("\033[1m\033[1;33m" + "|e Pvt. Ltd          Stock Exchang|" + '\033[0m', end = "")
    elif a%20 == 0 :
        print("\033[1m\033[1;33m" + "| Pvt. Ltd          Stock Exchange|" + '\033[0m', end = "")
    elif a%19 == 0 :
        print("\033[1m\033[1;33m" + "|Pvt. Ltd          Stock Exchange |" + '\033[0m', end = "")
    elif a%18 == 0 :
        print("\033[1m\033[1;33m" + "|vt. Ltd          Stock Exchange P|" + '\033[0m', end = "")
    elif a%17 == 0 :
        print("\033[1m\033[1;33m" + "|t. Ltd          Stock Exchange Pv|" + '\033[0m', end = "")
    elif a%16 == 0 :
        print("\033[1m\033[1;33m" + "|. Ltd          Stock Exchange Pvt|" + '\033[0m', end = "")
    elif a%15 == 0 :
        print("\033[1m\033[1;33m" + "| Ltd          Stock Exchange Pvt.|" + '\033[0m', end = "")
    elif a%14 == 0 :
        print("\033[1m\033[1;33m" + "|Ltd          Stock Exchange Pvt. |" + '\033[0m', end = "")
    elif a%13 == 0 :
        print("\033[1m\033[1;33m" + "|td          Stock Exchange Pvt. L|" + '\033[0m', end = "")
    elif a%12 == 0 :
        print("\033[1m\033[1;33m" + "|d          Stock Exchange Pvt. Lt|" + '\033[0m', end = "")
    elif a%11 == 0 :
        print("\033[1m\033[1;33m" + "|          Stock Exchange Pvt. Ltd|" + '\033[0m', end = "")
    elif a%10 == 0 :
        print("\033[1m\033[1;33m" + "|         Stock Exchange Pvt. Ltd |" + '\033[0m', end = "")
    elif a%9 == 0 :
        print("\033[1m\033[1;33m" + "|        Stock Exchange Pvt. Ltd  |" + '\033[0m', end = "")
    elif a%8 == 0 :
        print("\033[1m\033[1;33m" + "|       Stock Exchange Pvt. Ltd   |" + '\033[0m', end = "")
    elif a%7 == 0 :
        print("\033[1m\033[1;33m" + "|      Stock Exchange Pvt. Ltd    |" + '\033[0m', end = "")
    elif a%6 == 0 :
        print("\033[1m\033[1;33m" + "|     Stock Exchange Pvt. Ltd     |" + '\033[0m', end = "")
    elif a%5 == 0 :
        print("\033[1m\033[1;33m" + "|    Stock Exchange Pvt. Ltd      |" + '\033[0m', end = "")
    elif a%4 == 0 :
        print("\033[1m\033[1;33m" + "|   Stock Exchange Pvt. Ltd       |" + '\033[0m', end = "")
    elif a%3 == 0 :
        print("\033[1m\033[1;33m" + "|  Stock Exchange Pvt. Ltd        |" + '\033[0m', end = "")
    elif a%2 == 0 :
        print("\033[1m\033[1;33m" + "| Stock Exchange Pvt. Ltd         |" + '\033[0m', end = "")
def t():
    b = 2
    while b<34:
        
        
        if b>=34 :
            b = b - 33
        else :
            b = b + 1
        print("\r\t\t\t\t\t", end = "")
        new(b)
        time.sleep(0.1)

















    
        