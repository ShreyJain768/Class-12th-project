import tabulate, time, random, animation2, animation1, con_login, front_page, reset, st_info, pyttsx3

def space():
    print("\n\n\n\n\n\n\n")

def again():
    reset.clear()
    space()

def voice(com):
    engine = pyttsx3.init()
    engine.say(com)
    engine.runAndWait()

again()
animation1.anim()
voice('''Welcome To Stock Exchange Private Limited 
    Designed By Sshhrae, Sarthak and Gaoorav
    ''')
again()
lo_fp = front_page.front_lo()
again()


con_login.login_back(lo_fp)





    
