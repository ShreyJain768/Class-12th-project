import tabulate, time, random, reset, front_page, st_info, pyttsx3, adminmysql, mysql.connector, colors, csv, getpass, sys, msvcrt

def password_hide(prompt="Enter your password = "):
    print(prompt, end="", flush=True)
    password = ""
    while True:
        char = msvcrt.getch()  
        if char in {b'\r', b'\n'}:
            print()
            break
        elif char == b'\x08':
            if len(password) > 0:
                password = password[:-1]
                print("\b \b", end="", flush=True)
        else:
            password += char.decode("utf-8")
            print("*", end="", flush=True)
    return password


def voice(com):
    engine = pyttsx3.init()
    engine.say(com)
    engine.runAndWait()



def space():
    print("\n\n\n\n\n\n\n")

def again():
    reset.clear()
    space()

def will_log():
    space()
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    print("\t\t")
    print("                                                                                                                                                                                                                                              ")
    print("\tHow would you like to Procced ?",end = "\n")
    print("\tAdmin (2)              ","\tUser (3)                 ","\tEND (4)                 ","\tCreate New Account (1)                 ",sep = "\n", end = "\n\n\n\n\n")
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    
    tell = int(input("\033[A\033[A\033[A\033[A\033[A===>"))
    print("\n\n") 
    return tell

def num(price):
    while True:
        vary_num = round(random.uniform(-100,100),0)
        price = vary_num+price
        return price


def ft():
    st = [
    ["Reliance",num(2770),"","HDFC Bank",num(1657)],
    ["Infosys",num(1918),"","Tata Motors",num(930)],
    ["ONGC",num(295),"","ICICI Bank",num(1239)],
    ["Wipro",num(533),"","Bajaj Finance",num(7211)],
    ["Nestle",num(2598),"","BPCL",num(340)],
    ["Gold MCX",num(75427),"","Silver MCX",num(93500)],
    ["SBI",num(796),"","IGL",num(548)],
    ["TCS",num(4259),"","HCL Tech",num(1776)],
    ["Tata Steel",num(166),"","ITC",num(503)],
    ["HUL",num(2848),"","Cipla",num(1623)]
    ]
    return st



def ft_price():
    tab = tabulate.tabulate(ft(),headers = ["Stocks","Price","","Stocks","Price"],tablefmt = "grid")
    return tab

def ft_loop(tm):
    again()
    a = 1
    while True:
        if a == 1:
            print(ft_price(),end = "")
        else:
            print(
            f"\r\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A{ft_price()}"
            ,end = "")
        if a == tm:
            break
        a += 1
        time.sleep(1)



def logon_ad():
    while True:
        again()
        front_page.front_admin()
        what = int(input("\n==> "))
        if what == 3:
            again()
            colors.ORANGE()
            tm = int(input("How much time(sec) do you want to continue = "))
            colors.stop()
            ft_loop(tm)
        elif what == 4:
            again()
            st_info.st_information()
        elif what == 2:
            break
        elif what == 6:
            again()
            w = adminmysql.ad_acc_det()
            print("\033[1;34m"+"========================================================================================================================\n\n\n" + '\033[0m')
            print(tabulate.tabulate(w,headers = ["\033[33m ID \033[0m","\033[0;34m Names \033[0m","\033[0;32m Passwords \033[0m"],tablefmt = "grid"),end = "\n\n")
            print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
            if input("Do you want to import this data in CSV (y/n) = ")=="y".lower():
                with open("user_info.csv","w",newline="") as f:
                    k = csv.writer(f)
                    k.writerows(w)
                    print("You Data is imported into current Directory.")
            input("Press Enter to continue.")

def adm_loggedin():
    us_nm,us_ps = lgn_page()
    again()
    if us_nm == "Arun" and us_ps == "passwords":
        again()
        logon_ad()
        again()
    else:
        again()
        re_adm_lg()
        again()

def re_adm_lg():
    again()
    adm_loggedin()
    again()


def logon_us(p,q):
    while True:
        again()
        front_page.front_user()
        what = int(input("\n==> "))
        if what == 3:
            tm = int(input("How much time(sec) do you want to continue = "))
            ft_loop(tm)
            again()
        elif what == 4:
            st_info.st_information()
            again()
        elif what == 2:
            break
        elif what == 7:
            again()
            contact()
            again()
        elif what == 8:
            again()
            adminmysql.buying(p)
        elif what == 6:
            again()
            con = mysql.connector.connect(
            host="localhost",
            user="root",
            password="rj1212007"
            )
            mycursor = con.cursor()

            mycursor.execute("create database if not exists names;")
            mycursor.execute("use names")
            mycursor.execute("create table if not exists unames(Id int auto_increment ,Names varchar(50),Passwords varchar(50) ,primary key(Id));")
            con.commit()           
            mycursor.execute(f"select Names from unames where Id={p};")
            u = mycursor.fetchall()
            print("\033[1;34m"+"========================================================================================================================\n\n\n" + '\033[0m')
            print(f'''Hello {u[0][0]} welcome to Stock Exchange Pvt Ltd.
            
            User ID = {p}
            User Name = {u[0][0]}
            Password = {q} 
            
            ''')
            try:
                adminmysql.holdings(p)
                print("\n\n")               
            except Exception as e:
                print("There is no Share Holdings.")
                print("\n\n")

            print("\033[1;34m"+"========================================================================================================================\n" + '\033[0m')
            input("Press Enter to continue")
        elif what == 5:
            try:
                again()
                adminmysql.holdings(p)
                adminmysql.selling(p)
                input("Press Enter to Continue.")
            except Exception as e:
                print("There is no Share Holding at your Demate Account.")
                input("Press Enyer to Continue.")



def us_loggedin():
    us_nm,us_ps = lgn_page()
    p,q = adminmysql.fetching_data(us_nm)
    if us_ps == q:
        logon_us(p,q)
        again()
    else:
        re_us_lg()
        again()

def re_us_lg():
    us_loggedin()
    again()


def lgn_page():
    again()
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    print("\033[5m\033[1;33m\033[1m" + "\t\t\t\t\t|     Stock Exchange Pvt. Ltd     |\n" + '\033[0m')
    print("  " , end="\n\n")
    print("\t\t  ")
    print("\t\t ",end="\n\n\n\n\n\n")
    print("\033[1;34m"+"========================================================================================================================\n\n" + '\033[0m')
    print('\033[A\033[A\033[A\033[A\033[A\033[A\033[A\033[A')
    voice("Please input your I D AND password")
    usid = input("Enter your ID = ")
    usps = password_hide()
    print("\n\n\n")
    return usid,usps

b = 0

def login_back(lo_fp):

    while True:
        global b
        b += 1
        if b != 1:
            lo_fp = front_page.front_lo()
            again()
        if lo_fp == 1:
            while True:
                again()
                how = will_log()
                again()
                if how == 2:
                    adm_loggedin()
                    again()
                elif how == 3:
                    us_loggedin()
                    again()
                elif how == 1:
                    adminmysql.uact()
                else:
                    exit()
            
        elif lo_fp == 2:
            print("\n\n\n\n")
            tm = int(input("How much time(sec) do you want to continue = "))
            how = ft_loop(tm)
            again()
                
        elif lo_fp == 3:
            st_info.st_information()
            again()
            lo_fp = front_page.front_lo()
            again()
            
        elif lo_fp == 4:
            again()
            contact()
            again()


def contact():
    again()
    z=1
    if z==1:
        print('''\033[1;34m========================================================================================================================\033[0m
        
                                        \033[5m\033[1;33m\033[1m    |     Stock Exchange Pvt. Ltd     |     \033[0m
        
                    For Contact Us ==>

                    Landline Number : 91-90-8427 1630
                    Mobile Number   : +91 84459 50402
                                    : +91 80774 68871
                                      \n\n
\033[1;34m========================================================================================================================\033[0m                                                                         
                     ''')

        print("Press Enter to Continue.")
        input("==>")