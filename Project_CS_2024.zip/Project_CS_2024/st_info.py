    
def all_stocks():
    print('''
    \033[1;34m========================================================================================================================\033[0m
    
                                    \033[5m\033[1;33m\033[1m    |     Stock Exchange Pvt. Ltd     |     \033[0m
    
                Here are some stocks ==>

            \033[33m    Reliance     HDFC Bank     Infosys     Tata Motors     ONGC   \033[0m
                ICICI Bank     Wipro    \033[0;34m Bajaj Finance  \033[0m   Nestle     BPCL   \033[0m
                Gold MCX     Silver MCX   \033[0;34m     SBI     \033[0m     IGL        TCS   \033[0m
            \033[0;32m    HCL Tech     Tata Steel         ITC       HUL         Cipla    \033[0m

    \033[1;34m========================================================================================================================\033[0m
                                                                                   
                ''')

def st_information():
    all_stocks()
    while True :
        stock = input("Which stock do you want to study and type EXIT to end ==> ")
        print()
        if stock.lower() == 'HDFC Bank'.lower():
            print('''
            HDFC Bank Limited is an Indian banking and financial services company, headquartered in Mumbai.
            It is India s largest private sector bank by assets and the world tenth-largest bank by market capitalization as of May 2024.
            The Reserve Bank of India (RBI) has identified the HDFC Bank, State Bank of India,
            and ICICI Bank as Domestic Systemically Important Banks (D-SIBs), which are often referred to as banks that are “too big to fail”.
            As of April 2024, HDFC Bank has a market capitalization of $145 billion,
            making it the third-largest company on the Indian stock exchanges.
            It is also the sixteenth largest employer in India with over 173,000 employees,
            following its takeover of parent company Housing Development Finance Corporation.
            ''')

        elif stock.lower() == 'Reliance'.lower():
            print('''
            Reliance Industries Limited is an Indian multinational conglomerate headquartered in Mumbai, India.
            Its businesses include energy, petrochemicals, natural gas, retail, entertainment, telecommunications, mass media, and textiles.
            Reliance is the largest public company in India by market capitalisation and revenue, and the 100th largest company worldwide.
            It is India's largest private tax payer and largest exporter, accounting for 7% of India's total merchandise exports.
            ''')

        elif stock.lower() == 'Infosys'.lower():
            print('''
            Infosys Limited is an Indian multinational technology company that offers business consulting,
            information technology, and outsourcing services. Founded in Pune, the company is headquartered in Bangalore.
            On 24 August 2021, Infosys became the fourth Indian company to achieve a market capitalization of US$100 billion.
            It is recognized as one of the leading Big Tech (India) companies. As of 31 March 2024, 
            Infosys is the second-largest Indian IT company by revenue and the third-largest Indian company by market capitalization.
            ''')


        elif stock.lower() == 'Tata Motors'.lower():
            print('''
            Tata Motors Limited is an Indian multinational automotive company, headquartered in Mumbai and part of the Tata Group.
            The company produces cars, trucks, vans, and buses.
            Subsidiaries include British Jaguar Land Rover and South Korean Tata Daewoo.
            Tata Motors has joint ventures with Hitachi (Tata Hitachi Construction Machinery) and Stellantis,
            which makes vehicle parts for Fiat Chrysler and Tata-branded vehicles.
            Tata Motors has auto manufacturing and vehicle plants in Jamshedpur, Pantnagar, Lucknow,
            Sanand, Dharwad, and Pune in India, as well as in Argentina, South Africa, the United Kingdom, and Thailand.
            It has research and development centers in Pune, Jamshedpur, Lucknow, Dharwad, India and South Korea,
            the United Kingdom, and Spain. Tata Motors is listed on the BSE and NSE, and is a constituent of the BSE SENSEX
            and NIFTY 50 benchmark indices. 
            The company is ranked 265th on the Fortune Global 500 list of the world's biggest corporations as of 2019.
            On 17 January 2017, Natarajan Chandrasekaran was appointed chairman of the company Tata Group.
             Tata Motors increased its UV market share to over 8% in FY2019.
            ''')


        elif stock.lower() == 'ONGC'.lower():
            print('''
            The Oil and Natural Gas Corporation Limited (ONGC) is an Indian central public sector undertaking under the
            ownership of Ministry of Petroleum and Natural Gas, Government of India. The company is headquartered in Delhi. 
            ONGC was founded on 14 August 1956 by the Government of India. It is the largest government-owned-oil and gas
            explorer and producer in the country and produces around 70 percent of India's domestic production of crude oil
            and around 84 percent of natural gas.
            ONGC is vertically integrated across the entire oil and gas industry. In November 2010,
            the Government of India conferred the Maharatna status to ONGC.
            ''')




        elif stock.lower() == 'ICICI Bank'.lower():
            print('''
            ICICI Bank Limited is an Indian multinational bank and financial services company headquartered
            in Mumbai with a registered office in Vadodara. It offers a wide range of banking and financial services for
            corporate and retail customers through various delivery channels and specialized subsidiaries in the areas
            of investment banking, life, non-life insurance, venture capital and asset management.ICICI Bank has a network
            of 6,587 branches and 17,102 ATMs across India. It also has a presence in 11 countries. The bank has
            subsidiaries in the United Kingdom and Canada; branches in United States, Singapore, Bahrain, Hong Kong,
            Qatar, Oman, Dubai International Finance Centre, 
            China and South Africa; as well as representative offices in United Arab Emirates, Bangladesh,
            Malaysia and Indonesia. The company's UK subsidiary has also established branches in Belgium and Germany.
            The Reserve Bank of India (RBI) has identified the State Bank of India,
            HDFC Bank, and ICICI Bank as Domestic Systemically Important Banks (D-SIBs), which are often referred to
            as banks that are "too big to fail".
            ''')


        elif stock.lower() == 'Wipro'.lower():
            print('''
            Wipro Limited (/'Wipro; stylized in lowercase title) is an Indian multinational technology company
            that provides information technology, consulting and business process services. 
            It is one of the six leading Indian Big Tech companies. Wipro's capabilities range across cloud computing,
            computer security, digital transformation, artificial intelligence, robotics, data analytics,
            and other technologies, servicing customers in 167 countries.
            ''')


        elif stock.lower() == 'Bajal Finance'.lower():
            print('''
            Bajaj Finance Limited (BFL) is a deposit-taking Indian non-banking financial company 
            headquartered in Pune. It has a customer base of 88.11 million and holds assets under management worth ₹354,192 crore 
            (US$42 billion), as of June 2024. As per the 2023 list of NBFCs issued by the Reserve Bank of India, 
            Bajaj Finance Limited holds the second positionin the upper layer based on scale-based regulation guidelines.
            ''')




        elif stock.lower() == 'Nestle'.lower():
            print('''
            Nestlé  is a Swiss multinational food and drink processing conglomerate corporation headquartered in Vevey,
            Switzerland. It has been the largest publicly held food company in the world, measured by revenue and other metrics, since 2014.
            It ranked No. 64 on the Fortune Global 500 in 2017. In 2023, the company was ranked 50th in the Forbes Global 2000.
            ''')



        elif stock.lower() == 'BPCL'.lower():
            print('''
            Bharat Petroleum Corporation Limited (BPCL) is an Indian public sector undertaking (PSU) under the ownership
            of the Ministry of Petroleum and Natural Gas, Government of India. 
            It operates three refineries in Bina, Kochi and Mumbai. BPCL is India's second-largest government-owned downstream
            oil producer, whose operations are overseen by the Ministry of Petroleum and Natural Gas. 
            BPCL was ranked 309th on the Fortune list of the world's biggest PSUs in 2020, and 1052nd on Forbes's
            "Global 2000" list in 2023.
            ''')


        elif stock.lower() == 'Gold MCX'.lower():
            print('''
            Gold is the oldest precious metal known to man and for thousands of years it has been valued
            as a global currency, a commodity, an investment and simply an object of beauty.

            ''')


        elif stock.lower() == 'Silver MCX'.lower():
            print('''
            Silver is a brilliant grey-white metal that is soft and malleable. The mining of silver
            began some 5000 years ago, with the first mine being in Anatolia (modern-day Turkey). 
            The principal sources of silver are the ores of silver, silver-nickel, lead, and lead-zinc
            obtained from Peru, Bolivia, Mexico, China, Australia, Chile, Poland, and Serbia. Peru,
            Bolivia, and Mexico have been mining silver since 1546,
            and are still major world producers. Just over half of the mined silver comes from Mexico,
            Peru, China, and Australia, the four largest producing countries. Primary mines produce about
            one-third of the world silver, while around two-thirds
            come as a by-product of gold, copper, lead, and zinc mining. The top three silver-producing
            mines are Cannington (Australia), Fresnillo (Mexico), and San Cristobal (Bolivia). In Central Asia,
            Tajikistan is known to have some of the largest silver deposits in the world.
            ''')


        elif stock.lower() == 'IGL'.lower():
            print('''
            Indraprastha Gas Limited (IGL) is an Indian natural gas distribution company that supplies
            natural gas as cooking and vehicular fuel, primarily in Delhi NCR.
            Established in 1998, the company is a joint venture between GAIL, Bharat Petroleum, and the Government of Delhi.
            ''') 


        elif stock.lower() == 'SBI'.lower():
            print('''
            State Bank of India (SBI) is an Indian multinational public sector bank and financial
            services statutory body headquartered in Mumbai, Maharashtra.
            It is the 48th largest bank in the world by total assets and ranked 178th in the Fortune
            Global 500 list of the world's biggest corporations of 2024, 
            being the only Indian bank on the list.[11] It is a public sector bank and the
            largest bank in India[12] with a 23% market share by assets and
            a 25% share of the total loan and deposits market.[13] It is also the tenth
            largest employer in India with nearly 250,000 employees.
            In 2024, the company's seat in Forbes Global 2000 was 55.
            ''')


        elif stock.lower() == 'TCS'.lower():
            print('''
            Tata Consultancy Services (TCS) is an Indian multinational technology company
            specializing in information technology services and consulting. Headquartered in Mumbai,
            it is a part of the Tata Group and operates in 150 locations across 46 countries.
            It is the second-largest Indian company by market capitalization.
            ''')


        elif stock.lower() == 'HCL Tech'.lower():
            print('''
            HCL Technologies Limited (d/b/a HCLTech) is an Indian multinational information technology (IT)
            consulting company headquartered in Noida. Founded by Shiv Nadar,
            it was spun out in 1991 when HCL entered into the software services business.
            The company has offices in 60 countries and over 220,000 employees.
            ''')



        elif stock.lower() == 'Tata Steel'.lower():
            print('''
            Tata Steel Limited is an Indian multinational steel-making company,
            based in Jamshedpur, Jharkhand and headquartered in Mumbai, Maharashtra. It is a part of the Tata Group.
            Formerly known as Tata Iron and Steel Company Limited (TISCO), Tata Steel is among the 
            largest steel producing companies in the world, with an annual crude steel capacity of 35 million tonnes.
            It is one of the world's most geographically diversified steel producers, 
            with operations and commercial presence across the world. 
            The group (excluding SEA operations) recorded a consolidated turnover of US$31 
            billion in the financial year ending 31 March 2023. It is the largest steel 
            company in India (measured by domestic production)
            with an annual capacity of 21.6 million tonnes after Steel Authority of India Ltd.
            (SAIL). Tata Steel, SAIL, and Jindal Steel and Power,
            are the only three Indian steel companies that have captive iron-ore mines, 
            which gives the three companies price advantages.
            ''')


        elif stock.lower() == 'ITC'.lower():
            print('''
            ITC Limited is an Indian conglomerate company, headquartered in Kolkata.
            It has a presence across six business segments, namely FMCG, hotels, agribusiness, information technology,
            paper products, and packaging.[10] It generates a plurality of its revenue from tobacco products. 
            In terms of market capitalization, ITC is the second-largest FMCG company in India and the third-largest
            tobacco company in the world. It employs 36,500 people at more than 60 locations across India.
            Its products are available in 6 million retail outlets in India and exported to 90 countries.
            ''')


        elif stock.lower() == 'HUL'.lower():
            print('''
            Hindustan Unilever Limited (HUL) is an Indian fast-moving consumer goods company, 
            headquartered in Mumbai.[3] It is a subsidiary of the British company Unilever. 
            Its products include foods, beverages, cleaning agents,
            personal care products and other consumer staples.As of 2019,
            Hindustan Unilever's portfolio had more than 50 product brands in 14 categories. 
            The company has 21,000 employees and recorded sales of ₹34,619 crores in FY2017-18.
            ''')


        elif stock.lower() == 'Cipla'.lower():    
            print('''
            Cipla Limited is an Indian multinational pharmaceutical company headquartered in Mumbai. 
            Cipla primarily focuses on developing medication to treat respiratory disease, cardiovascular disease,
            arthritis, diabetes, depression, paediatric and various other medical conditions. 
            Cipla has 47 manufacturing locations across the world and sells its products in 86 countries. 
            It is the third-largest drug producer in India
            ''')                         

        elif stock.lower() == "EXIT".lower():
            break

        else :
            print("Sorry but this stock is not registered right now.")